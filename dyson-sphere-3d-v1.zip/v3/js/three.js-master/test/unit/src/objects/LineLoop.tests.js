/* global QUnit */

import { LineLoop } from '../../../../src/objects/LineLoop';

export default QUnit.module( 'Objects', () => {

	QUnit.module( 'LineLoop', () => {

		// INHERITANCE
		QUnit.todo( "Extending", ( assert ) => {

			assert.ok( false, "everything's gonna be alright" );

		} );

		// INSTANCING
		QUnit.todo( "Instancing", ( assert ) => {

			assert.ok( false, "everything's gonna be alright" );

		} );

		// PUBLIC STUFF
		QUnit.todo( "isLineLoop", ( assert ) => {

			assert.ok( false, "everything's gonna be alright" );

		} );


	} );

} );
