/* global QUnit */

import { ArrayCamera } from '../../../../src/cameras/ArrayCamera';

export default QUnit.module( 'Cameras', () => {

	QUnit.module( 'ArrayCamera', () => {

		// INHERITANCE
		QUnit.todo( "Extending", ( assert ) => {

			assert.ok( false, "everything's gonna be alright" );

		} );

		// INSTANCING
		QUnit.todo( "Instancing", ( assert ) => {

			assert.ok( false, "everything's gonna be alright" );

		} );

		// PUBLIC STUFF
		QUnit.todo( "isArrayCamera", ( assert ) => {

			assert.ok( false, "everything's gonna be alright" );

		} );

	} );

} );
