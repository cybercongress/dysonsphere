/* global QUnit */

import { VectorKeyframeTrack } from '../../../../../src/animation/tracks/VectorKeyframeTrack';

export default QUnit.module( 'Animation', () => {

	QUnit.module( 'Tracks', () => {

		QUnit.module( 'VectorKeyframeTrack', () => {

			QUnit.todo( 'write me !', ( assert ) => {

				assert.ok( false, "everything's gonna be alright" );

			} );

		} );

	} );

} );
