/* global QUnit */

import { MeshNormalMaterial } from '../../../../src/materials/MeshNormalMaterial';

export default QUnit.module( 'Materials', () => {

	QUnit.module( 'MeshNormalMaterial', () => {

		// INHERITANCE
		QUnit.todo( "Extending", ( assert ) => {

			assert.ok( false, "everything's gonna be alright" );

		} );

		// INSTANCING
		QUnit.todo( "Instancing", ( assert ) => {

			assert.ok( false, "everything's gonna be alright" );

		} );

		// PUBLIC STUFF
		QUnit.todo( "isMeshNormalMaterial", ( assert ) => {

			assert.ok( false, "everything's gonna be alright" );

		} );

		QUnit.todo( "copy", ( assert ) => {

			assert.ok( false, "everything's gonna be alright" );

		} );

	} );

} );
