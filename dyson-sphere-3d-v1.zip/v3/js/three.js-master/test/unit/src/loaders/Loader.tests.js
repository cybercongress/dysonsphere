/* global QUnit */

export default QUnit.module( 'Loaders', () => {

	QUnit.module( 'Loader', () => {

		// INSTANCING
		QUnit.todo( "Instancing", ( assert ) => {

			assert.ok( false, "everything's gonna be alright" );

		} );

	} );

} );
