/*jshint esversion: 6 */

// Custom ThreeJs Master by Amin Shahrokhi

// Importing the required libraries
import * as THREE from './three.js-master/build/three.module.js';
import {GLTFLoader} from './three.js-master/examples/jsm/loaders/GLTFLoader.js';
import {OrbitControls} from './three.js-master/examples/jsm/controls/OrbitControls.js';
import {EffectComposer} from './three.js-master/examples/jsm/postprocessing/EffectComposer.js';
import {RenderPass} from './three.js-master/examples/jsm/postprocessing/RenderPass.js';
import {ShaderPass} from './three.js-master/examples/jsm/postprocessing/ShaderPass.js';
import {OutlinePass} from './three.js-master/examples/jsm/postprocessing/OutlinePass.js';
import {FXAAShader} from './three.js-master/examples/jsm/shaders/FXAAShader.js';
import {UnrealBloomPass} from './three.js-master/examples/jsm/postprocessing/UnrealBloomPass.js';
import { VertexNormalsHelper } from './three.js-master/examples/jsm/helpers/VertexNormalsHelper.js';
// import Stats from './stats.module.js';

// Defining the variables
var json_data, renderer, scene, camera, controls, renderScene, bloomPass, bloomComposer, outlinePass, finalPass, finalComposer, raycaster, mouse, root, clock, mixer, light_1, light_2, galaxy, snubTween, snub, moon, cameraTween, galaxy;
var glowObj,mouseUp;
var texts = [];
const textColor = 0xFFFFFF;
const textClickColor = 0x000000;
// const stats = new Stats();

var camPositions = [
	[-12.946,-1.096,-12.458],
	[-3.557,-16.642,-5.865],
	[-15.801,-6.883,5.191],
	[5.293,-4.106,-16.707],
	[-13.595,11.708,1.442],
	[-0.822,13.188,-12.223],
	[3.842,16.414,6.310],
	[-5.439,4.425,16.578],
	[1.169,-13.219,12.161],
	[13.066,1.029,12.338],
	[15.835,7.050,-4.853],
	[-4.845,-9.058,-14.781],
	[-1.908,-12.100,-13.189],
	[-10.033,-11.841,-9.118],
	[-8.884,-8.915,-12.868],
	[4.348,-16.423,-5.948],
	[2.863,-11.703,-13.374],
	[6.672,-13.314,-10.111],
	[10.818,-11.177,-9.057],
	[11.820,-7.022,-11.618],
	[-3.250,-5.436,-16.849],
	[-5.266,-0.557,-17.203],
	[6.348,-16.698,-2.210],
	[5.077,-17.155,1.978],
	[-1.061,-17.900,1.573],
	[-2.791,-16.877,5.603],
	[-8.679,-15.106,4.525],
	[-9.205,-15.456,0.603],
	[-13.935,-11.298,-1.479],
	[-13.475,-10.482,-5.706],
	[-15.811,-5.582,-6.545],
	[10.898,-12.854,6.325],
	[5.933,-15.786,6.292],
	[-10.043,-12.425,8.292],
	[-7.463,-11.383,11.778],
	[7.768,-9.259,13.339],
	[11.388,-9.734,9.978],
	[14.145,-6.141,9.285],
	[7.889,-4.516,15.536],
	[3.421,-3.317,17.358],
	[-0.595,-6.132,16.913],
	[-4.726,-4.689,16.724],
	[-8.568,-6.548,14.412],
	[-12.354,-4.375,12.338],
	[-16.899,1.784,5.937],
	[-12.356,0.892,13.058],
	[-14.679,3.258,9.895],
	[2.383,1.226,17.799],
	[6.339,4.559,16.218],
	[4.588,9.176,14.790],
	[0.068,10.325,14.744],
	[-9.097,9.688,12.140],
	[-12.983,8.765,8.867],
	[-17.375,-4.242,-2.031],
	[-16.333,3.094,-6.904],
	[13.635,-11.679,-1.303],
	[-17.744,1.610,-2.560],
	[-17.628,3.210,1.723],
	[-14.573,8.534,-6.229],
	[-11.599,9.514,-9.948],
	[-9.780,7.117,-13.331],
	[-7.899,13.812,-8.416],
	[-0.472,17.341,-4.801],
	[16.610,-4.483,-5.291],
	[10.404,9.750,-10.986],
	[16.802,2.375,6.004],
	[17.815,-1.247,2.249],
	[7.987,11.015,11.785],
	[11.482,9.434,10.157],
	[16.297,-5.795,4.983],
	[-5.797,7.484,-15.310],
	[-7.816,15.210,5.618],
	[14.160,1.048,-11.064],
	[7.192,13.542,-9.429],
	[1.661,3.414,-17.595],
	[-4.546,17.344,-1.584],
	[14.918,-3.450,-9.463],
	[8.293,15.086,-5.258],
	[13.547,10.190,6.054],
	[-1.430,13.838,11.422],
	[4.094,17.425,-1.897],
	[8.286,6.608,-14.549],
	[-3.326,3.425,-17.355],
	[4.348,7.551,-15.750],
	[-8.719,15.022,-4.723],
	[-4.127,17.354,2.409],
	[10.593,1.664,-14.457],
	[17.937,-0.569,-1.391],
	[11.279,13.732,2.866],
	[16.482,6.703,2.720],
	[-6.421,13.598,9.892],
	[11.652,13.617,-1.678]
];
var zAxisDisplacement = [
	0,
	12, -10, 0, -6,
	0, 0, 0, 0, -10,
	5, -12, -28, 30, 11,
	16, 2, -5, 0, 12,
	10, -22, -22, -19, 16,
	-12, 0, 12, -14, 0,
	0, 0, -36, -14, 10,
	0, -12, -20, -22, -10,
	-7, -3, 0, 0, 2,
	2, 6, 1, -4, -7,
	-4, -19, 11, 4, 0,
	-6, -6, 0, 0, 0,
	-9, -15, -15, 0, 16, //60
	8, 16, 22, 0, 6,
	28, -25, 0, 15, 19,
	25, 0, 15, 0, 15,
	-20, 0, 0, -22, 22,
	0, 0, 12, 22, 22,
	22, 12, -12, 0, 0
]

var jsonFont = '../fonts/play/Play_Regular.json';

let selectedObjects = [];
let hoveredItem = -1;
var baseLinewidth = .7;
var baseWireframeColor = 0x154f40;
var playing = true;
var autoRotate = true;
var record = '';

var intersects;
var moonSpin = true;

const noBlooms = [];

const ENTIRE_SCENE = 0, BLOOM_SCENE = 1;

const bloomLayer = new THREE.Layers();
bloomLayer.set(BLOOM_SCENE);

const params = {
	exposure: 0.6,
	bloomStrength: 2,
	bloomThreshold: 0,
	bloomRadius: 0.7,
	scene: "Scene with Glow"
};

const darkMaterial = new THREE.MeshBasicMaterial({ color: "black" });
const materials = {};

var data = [];
var response;
var temp = [];
var ajax = document.getElementById('ajax');
const xhttp = new XMLHttpRequest();
xhttp.onload = function() {
    json_data = this.responseText;
    response = JSON.parse(json_data);
	temp = response.validators;
	ajax.value = 1;
}
// xhttp.open("GET", "lcd.json");
xhttp.open("GET", "https://lcd.bostrom.cybernode.ai/cosmos/staking/v1beta1/validators");
xhttp.send();

// Load the scene when AJAX data received
observeElement(ajax, 'value', function(oldValue, newValue) {
	for(var d = 0; d < temp.length; d++) {
		data.push([[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]);
		var max_change_rate = temp[d].commission.commission_rates.max_change_rate;
		var max_rate = temp[d].commission.commission_rates.max_rate;
		var rate = temp[d].commission.commission_rates.rate;
		var update_time = temp[d].commission.update_time;
		var key = temp[d].consensus_pubkey.key;
		var delegator_shares = temp[d].delegator_shares;
		var details = temp[d].description.details;
		var identity = temp[d].description.identity;
		var moniker = temp[d].description.moniker;
		var security_contact = temp[d].description.security_contact;
		var website = temp[d].description.website;
		var jailed = temp[d].jailed;
		var min_self_delegation = temp[d].min_self_delegation;
		var operator_address = temp[d].operator_address;
		var status = temp[d].status;
		var tokens = temp[d].tokens;
		var unbonding_height = temp[d].unbonding_height;
		var unbonding_time = temp[d].unbonding_time;
		var jailed = temp[d].jailed;

		data[d][0] = d + 1;
		data[d][1] = max_change_rate;
		data[d][2] = max_rate;
		data[d][3] = rate;
		data[d][4] = update_time;
		data[d][5] = key;
		data[d][6] = delegator_shares;
		data[d][7] = details;
		data[d][8] = identity;
		data[d][9] = moniker;
		data[d][10] = security_contact;
		data[d][11] = website;
		data[d][12] = jailed;
		data[d][13] = min_self_delegation;
		data[d][14] = operator_address;
		data[d][15] = status;
		data[d][16] = tokens;
		data[d][17] = unbonding_height;
		data[d][18] = unbonding_time;
		data[d][19] = jailed;
	}

	if(parseInt(newValue) > 0) {
		init();
		setupScene();

		THREE.DefaultLoadingManager.onLoad = function() {
			animate();
			// if(document.getElementById('preloader')) {
			// 	document.getElementById('preloader').classList.add('removed');
			// }
		};
	}
});

function init() {
	// Creating the scene
	scene = new THREE.Scene();

	// Adding the clock to the application
	clock = new THREE.Clock();
	
	// Defining the renderer
	renderer = new THREE.WebGLRenderer({ antialias: true });
	renderer.setPixelRatio(window.devicePixelRatio);
	renderer.setSize(window.innerWidth, window.innerHeight);
	renderer.toneMapping = THREE.ReinhardToneMapping;
	renderer.toneMappingExposure = 0.7;
	document.body.appendChild(renderer.domElement);
// 	document.body.appendChild(stats.dom);
	// Defining and setting up the camera
	camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1, 200);
	camera.position.set(0, 0, 18);
	camera.lookAt(0, 0, 0);

	// Creating controller
	controls = new OrbitControls(camera, renderer.domElement);
	// controls.maxPolarAngle = Math.PI * 0.5;
	controls.enablePan = false;
	controls.enableDamping = true;
	controls.dampingFactor = 0.08;
	controls.target.set(0,0,0);
	controls.autoRotateSpeed = .2;
	controls.enabled = true;
	controls.minDistance = 18;
	controls.maxDistance = 18;
	controls.addEventListener('start',function(){
		if(cameraTween)
			cameraTween.stop();
	});

	
	scene.add(new THREE.AmbientLight(0x404040));

	renderScene = new RenderPass(scene, camera);

	bloomPass = new UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), 1.5, 0.4, 0.85);
	bloomPass.threshold = params.bloomThreshold;
	bloomPass.strength = params.bloomStrength;
	bloomPass.radius = params.bloomRadius;

	bloomComposer = new EffectComposer(renderer);
	bloomComposer.renderToScreen = false;
	bloomComposer.addPass(renderScene);
	bloomComposer.addPass(bloomPass);

	outlinePass = new OutlinePass(new THREE.Vector2(window.innerWidth, window.innerHeight), scene, camera);
	bloomComposer.addPass(outlinePass);

	finalPass = new ShaderPass(
		new THREE.ShaderMaterial({
			uniforms: {
				baseTexture: { value: null },
				bloomTexture: { value: bloomComposer.renderTarget2.texture }
			},
			vertexShader: document.getElementById('vertexshader').textContent,
			fragmentShader: document.getElementById('fragmentshader').textContent,
			defines: {}
		}), "baseTexture"
	);
	finalPass.needsSwap = true;

	finalComposer = new EffectComposer(renderer);
	finalComposer.addPass(renderScene);
	finalComposer.addPass(finalPass);

	raycaster = new THREE.Raycaster();

	mouse = new THREE.Vector2();
	mouseUp = new THREE.Vector2();



	// document.getElementById('trace').addEventListener('pointerdown', function() {
	// 	console.log(camera.position.x.toFixed(3) + ',' + camera.position.y.toFixed(3) + ',' + camera.position.z.toFixed(3));
	// });
}

// Locating objects and elements
function setupScene() {
	galaxy = scene.getObjectByName('galaxy');
	// Adding lights to the scene
	light_1 = addDirectionalLight(0xffffff, 1.5, 13, 2.4, 0, true, scene);
	light_2 = addDirectionalLight(0xffffff, 1.5, -13, -2.4, 0, true, scene);

	// Adding the galaxy
	galaxy = addTexturedSphere(100, 0, 0, 0, 50, 'images/galaxy.png', scene, 'galaxy', true);

	// Adding the Snub Dodecahedron
	getGLTF(
		'3d/snub c.gltf',
		4,  			// Size
		0,  			// Pos X
		0,  			// Pos Y
		0,  			// Pos Z
		-Math.PI/2,  	// Rot X
		0,  			// Rot Y
		0,  			// Rot Z
		scene, 			// base
		'snub', 		// name
		false, 			// receiveShadow
		1, 				// roughness
		.2, 			// metalness
		.5, 			// opacity
		undefined, 		// color
		false			// wireframe
	);
	moon = getMoon(3, 0.5, 1, 0, 0, 0, 0, 0, 0, 'circle', scene);

	loadSidebar();

	window.addEventListener('pointerdown', onPointerDown);
	window.addEventListener('pointerup', onPointerUp);

	document.getElementById('list').addEventListener('pointermove', onPointerMove);

}

function onPointerMove(ev) {
	var id = ev.target.id.slice(5);
	if(!isNaN(parseInt(id)) && id != hoveredItem) {

		hoveredItem = parseInt(id);
		var circle = scene.getObjectByName('circle');
		var obj = snub.children[hoveredItem - 1];

		snub.traverse(function(child) {
			if(child instanceof THREE.Mesh) {

				// if(typeof child.name === 'string' && child.name.startsWidth('w_')) {
				// 	child.material.color.set(baseWireframeColor);
				// 	child.material.linewidth = baseLinewidth;
				// }

				// var wf = scene.getObjectByName(obj.children[0].name);

				if(!isNaN(child.name)) {
					// console.log(child.name);
					var wf = scene.getObjectByName(child.children[0].name);
				}

				if(wf != undefined) {
					if(child.name === hoveredItem) {
						autoRotate = false;
						//moveCamera(hoveredItem - 1);

						wf.material.color.set(0xFFFFFF);
						wf.material.linewidth = 3;

						// console.log(wf.userData.position);
						// camera.position.set(wf.userData.position.x, wf.userData.position.y, wf.userData.position.z);

						// circle.lookAt(wf.userData.position);
					}
					else {
						wf.material.color.set(baseWireframeColor);
						wf.material.linewidth = baseLinewidth;
					}
				}
			}
		});
	}
}

// function onPointerMove2(event) {
// 	if(event.isPrimary === false) return;
//
// 	mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
// 	mouse.y = - (event.clientY / window.innerHeight) * 2 + 1;
// 	checkIntersection();
// }
//
// function addSelectedObject(object) {
// 	selectedObjects = [];
// 	selectedObjects.push(object);
// }
//
// function checkIntersection() {
// 	raycaster.setFromCamera(mouse, camera);
// 	const intersects = raycaster.intersectObject(scene, true);
//
// 	if(intersects.length > 0) {
// 		const selectedObject = intersects[0].object;
// 		addSelectedObject(selectedObject);
// 		outlinePass.selectedObjects = selectedObjects;
// 	} else {
// 		// outlinePass.selectedObjects = [];
// 	}
// }

// Watching elements for any change in value
observeElement(tracker, 'value', function(oldValue, newValue) {
	if(parseInt(newValue) > -1) {
		var tracked = newValue - 1;

		var place = data[tracked][0];
		var moniker = data[tracked][9];
		var commission = data[tracked][3];
		var power = data[tracked][3];
		var power_percent = data[tracked][4];
		var self = data[tracked][13];
		var bond = data[tracked][17];

		document.getElementById('place').innerText = place;
		document.getElementById('moniker').innerText = moniker;
		document.getElementById('commission').innerText = commission;
		document.getElementById('power').innerText = power;
		document.getElementById('power_percentage').innerText = power_percent;
		document.getElementById('self').innerText = self;
		document.getElementById('bond').innerText = bond;
	}
	else {
/* 		snubTween = new TWEEN.Tween(snub.position)
		.to({x: 0, y: 0, z: 0}, 2000)
		.easing(TWEEN.Easing.Cubic.InOut)
		.start();
 */
		autoRotate = true;
	}

});

// Loading data to the left sidebar
function loadSidebar() {
	for(var l = 0; l < data.length; l++) {
		var maxLength = 16;
		var nickname = data[l][9];
		if(nickname.length > maxLength) {
			var name = nickname.substring(0, maxLength) + '...';
		}
		else {
			var name = nickname.substring(0, maxLength);
		}
		var item = '<li class="item" id="item_' + data[l][0] + '"><span class="id">' + data[l][0] + '</span><span class="stat fa fa-circle"></span><span class="name">' + name + '</span></li>';
		document.getElementById('items').innerHTML += item;
		
	}
}

// Responding to the screen change event
window.onresize = function () {
	const width = window.innerWidth;
	const height = window.innerHeight;

	camera.aspect = width / height;
	camera.updateProjectionMatrix();

	renderer.setSize(width, height);

	bloomComposer.setSize(width, height);
	finalComposer.setSize(width, height);


};

function onPointerDown(event) {


	mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
	mouse.y = - (event.clientY / window.innerHeight) * 2 + 1;

	raycaster.setFromCamera(mouse, camera);
	intersects = raycaster.intersectObjects(snub.children, false);

	/*var target = $(event.target);

	//Checking clicked item's parent has "item" class
	if(target.parent('li').hasClass('item')){
		//Item's id
		var id = parseInt(target.parent('li').attr('id').replace('item_',''));
		
		var clicked_obj = snub.children[id-1];
	
		unbloom(snub);

		clicked_obj.layers.toggle(BLOOM_SCENE);
		outlinePass.selectedObjects = clicked_obj;
		//To prevent unbloom function from happening.
		moveCamera(id - 1);
		cameraTween.start();
		return 0;
	}
	if(target.parents('div#popup').length) {
		// It happens when the large popup is opened and the click has been on one of its child elements
		if(event.target.id == 'close_popup') {
			unbloom(snub);
		}
	}
	else {
		if(intersects.length > 0) {
			autoRotate = false;
			unbloom(snub)

			const object = intersects[0].object;
			object.layers.toggle(BLOOM_SCENE);
			record = object.name;
			outlinePass.selectedObjects = object;

			var item = showRecord(record);

			var track = parseInt(item.userData.place);

			if(data[track] != undefined) {
				var operation_address = data[track][14];
				var address = data[track][5];
				var identity = data[track][7];
				var delegator_shared = data[track][6];
				var token = data[track][16];
				var commission_rate = data[track][3];
				var max_rate = data[track][2];
				var max_change_rate = data[track][1];
				var self_stake = data[track][13];
				var details = data[track][7];*/

/* 				var main_content = '<ul class="info">';
				main_content += '<li><span class="label">Operation Address: </span><span>' + operation_address + '</span></li>';
				main_content += '<li><span class="label">Address: </span><span>' + address + '</span></li>';
				main_content += '<li><span class="label">Identity: </span><span>' + identity + '</span></li>';
				main_content += '<li><span class="label">Delegator Shared: </span><span>' + delegator_shared + '</span></li>';
				main_content += '<li><span class="label">Token: </span><span>' + token + '</span></li>';
				main_content += '<li><span class="label">Commission Rate: </span><span>' + commission_rate + '</span></li>';
				main_content += '<li><span class="label">Max. Rate: </span><span>' + max_rate + '</span></li>';
				main_content += '<li><span class="label">Max. Exchange Rate: </span><span>' + max_change_rate + '</span></li>';
				main_content += '<li><span class="label">Self Stake: </span><span>' + self_stake + '</span></li>';
				main_content += '<li><span class="label">Details: </span><span>' + details + '</span></li>';
				main_content += '</ul>';
				document.getElementById('main_content').innerHTML = main_content; */

				// var snubTween = new TWEEN.Tween(snub.position)
				// .to({x: -4, y: 0, z: 0}, 2000)
				// .easing(TWEEN.Easing.Cubic.InOut)
				// .start();
				//
				// var cameraTween = new TWEEN.Tween(camera.position)
				// .to({x: 0, y: 0, z: 18}, 2000)
				// .easing(TWEEN.Easing.Cubic.Out)
				// .onComplete(function() {
				// 	// Change the #tracker hidden input on intersect click
				// 	var input = document.getElementById('tracker');
				// 	input.value = item.userData.place;
				//
				// 	// Trigger event on input change
				// 	var event = new Event('input', {
				// 		bubbles: true,
				// 		cancelable: true,
				// 	});
				// 	input.dispatchEvent(event);
				// })
				// .start();

/* 				moveCamera(track - 1);

				// Change the #tracker hidden input on intersect click
				var input = document.getElementById('tracker');
				input.value = item.userData.place;

				// 	// Trigger event on input change
				var event = new Event('input', {
					bubbles: true,
					cancelable: true,
				});
				input.dispatchEvent(event);

				render();
			}
		}
		else {
			unbloom(snub);
		}
	} */
	
}

// Move camera to front of the selected piece
function moveCamera(num) {
	var pos = camPositions[num];
	// console.log(pos);
	cameraTween = new TWEEN.Tween(camera.position)
	.to({x: pos[0], y: pos[1], z: pos[2]}, 2000)
	.easing(TWEEN.Easing.Cubic.Out);

	
	//.onComplete(function() {
		// // Change the #tracker hidden input on intersect click
		// var input = document.getElementById('tracker');
		// input.value = item.userData.place;
		//
		// // Trigger event on input change
		// var event = new Event('input', {
		// 	bubbles: true,
		// 	cancelable: true,
		// });
		// input.dispatchEvent(event);
	//})
	
}

function unbloom(snub) {
	snub.traverse(function(child) {
		
		if(child.parent instanceof THREE.Group){
				child.layers.set(ENTIRE_SCENE);
				
				revertTextColor();


			}
		
	});

	// Change the #tracker hidden input on intersect click
	var input = document.getElementById('tracker');
	input.value = -1;

	// Trigger event on input change
	var event = new Event('input', {
		bubbles: true,
		cancelable: true,
	});
	input.dispatchEvent(event);

/* 	snubTween = new TWEEN.Tween(snub.position)
	.to({x: 0, y: 0, z: 0}, 2000)
	.easing(TWEEN.Easing.Cubic.InOut)
	.start(); */

	autoRotate = true;
}
function changeTextColor(id){
		texts[id-1].material.color = new THREE.Color(textClickColor);
		texts[id-1].material.emissive = new THREE.Color(textClickColor);

}
function revertTextColor(){
	//Revert text colors
	texts.forEach(function(text){
		text.material.color = new THREE.Color(textColor);
		text.material.emissive = new THREE.Color(textColor);
	})
}
// Load the data relevant to the clicked object in the popup
function showRecord(name) {
	var item = scene.getObjectByName(name);
	return item;
}

// Observes an element for further changes
function observeElement(element, property, callback, delay = 0) {
    let elementPrototype = Object.getPrototypeOf(element);
    if(elementPrototype.hasOwnProperty(property)) {
        let descriptor = Object.getOwnPropertyDescriptor(elementPrototype, property);
        Object.defineProperty(element, property, {
            get: function() {
                return descriptor.get.apply(this, arguments);
            },
            set: function() {
                let oldValue = this[property];
                descriptor.set.apply(this, arguments);
                let newValue = this[property];
                if(typeof callback == "function") {
                    setTimeout(callback.bind(this, oldValue, newValue), delay);
                }
                return newValue;
            }
        });
    }
}

// Sets the object's visibility
function getVisibility(name, parent, visibility) {
	var object = parent.getObjectByName(name);
	object.traverse(function(child) {
		if(child instanceof THREE.Mesh) {
			if(parseInt(visibility) > 0) {
				child.visible = true;
			}
			else {
				child.visible = false;
			}
		}
	});
}

// Set the opacity of object mesh
function getOpacity(name, parent, opacity) {
	var object = parent.getObjectByName(name);
	object.traverse(function(child) {
		if(child instanceof THREE.Mesh) {
			child.material.opacity = parseFloat(opacity);
		}
	});
}

function disposeMaterial(obj) {
	if(obj.material) {
		obj.material.dispose();
	}
}

// Unlimited lights can be added to the scene
function addPointLight(x, y, z, color, intensity, parent) {
    var light = new THREE.PointLight(color, intensity);
    light.position.set(x,y,z);
	parent.add(light);
}

// Creates directional lights
function addDirectionalLight(color, intensity, x, y, z, castShadow, parent) {
	var directionalLight = new THREE.DirectionalLight(color, intensity, 100);
	directionalLight.position.set(x, y, z);
	directionalLight.castShadow = castShadow;
	parent.add(directionalLight);
}

// Supports both GLTF and GLB
function getGLTF(path, size, x, y, z, rx, ry, rz, base, name, receiveShadow, roughness, metalness, opacity, color, wireframe) {
	const loader = new GLTFLoader();
		loader.load(path, function(gltf) {
			root = gltf.scene;
			root.scale.set(size, size, size);
			root.position.set(x,y,z);
			root.rotation.set(rx,ry,rz);
			root.name = name;
			//Defining a basic matrial that light won't affect it.
			var colorNormal = gltf.scene.children[0].material.color;
			var normalMat = new THREE.MeshBasicMaterial({
				color: colorNormal,
				transparent: true,
				opacity: opacity,
				side: THREE.DoubleSide
			})

			//Defining a material for disabled items.
			var disabledMat = normalMat.clone();
			disabledMat.opacity = 0;

			//Defining a material for jailed items
			var jailedMat = normalMat.clone();
			jailedMat.color = new THREE.Color(0xEEEE44);
			

			var count = 0;
			root.traverse(function(child) {
				if(child.isMesh) {
					// The mesh can be modified with the values below:
					child.material = normalMat;
					// child.material.transparent = true;
					// child.material.opacity = opacity;
					child.frustumCulled = false;
					// child.material.roughness = roughness;
					// child.material.metalness = metalness;
					if(color != undefined) child.material.color.set(color);
					if(wireframe != undefined) child.material.wireframe = wireframe;
					// if(receiveShadow) {
					// 	child.castShadow = true;
					// 	child.receiveShadow = receiveShadow;
					// }
					child.name = count + 1;
					child.geometry.computeBoundingSphere();
					var vector = child.geometry.boundingSphere.center;
					var position = new THREE.Vector3();
					var quaternion = new THREE.Quaternion();
					var scale = new THREE.Vector3();
					child.matrixWorld.decompose(position, quaternion, scale);
					child.updateMatrixWorld(true);

					var geo = new THREE.EdgesGeometry(child.geometry); // or WireframeGeometry
					var mat = new THREE.LineBasicMaterial({color: baseWireframeColor, linewidth: baseLinewidth});
					var wireframe = new THREE.LineSegments(geo, mat);
					wireframe.name = 'w_' + (count + 1);
					wireframe.userData.position = vector;
					child.add(wireframe);

					if(count < data.length) {
						var pic = addPicture(0.15, 0.15, x, y, z, 0, 0, 0, child,'label_' + (count + 1), '');	
						var label = addText(jsonFont, data[count][9], 0, 0, 0, 0, 0, 0, child, 'text_' + (count + 1), .025, textColor,count+1);
						
						// var str = data[count][0];
						// var label = addText(jsonFont, 'No.' + str, vector.x, vector.y, vector.z, 0, 0, 0, child, 'label_' + (count + 1), .05, 0xFFFFFF);

						if(data[count][0]) child.userData.place = data[count][0];
						if(data[count][1]) child.userData.max_change_rate = data[count][1];
						if(data[count][2]) child.userData.max_rate = data[count][2];
						if(data[count][3]) child.userData.rate = data[count][3];
						if(data[count][4]) child.userData.update_time = data[count][4];
						if(data[count][5]) child.userData.key = data[count][5];
						if(data[count][6]) child.userData.delegator_shares = data[count][6];
						if(data[count][7]) child.userData.details = data[count][7];
						if(data[count][8]) child.userData.identity = data[count][8];
						if(data[count][9]) child.userData.moniker = data[count][9];
						if(data[count][10]) child.userData.security_contact = data[count][10];
						if(data[count][11]) child.userData.website = data[count][11];
						if(data[count][12]) child.userData.jailed = data[count][12];
						if(data[count][13]) child.userData.min_self_delegation = data[count][13];
						if(data[count][14]) child.userData.operator_address = data[count][14];
						if(data[count][15]) child.userData.status = data[count][15];
						if(data[count][16]) child.userData.tokens = data[count][16];
						if(data[count][17]) child.userData.unbonding_height = data[count][17];
						if(data[count][18]) child.userData.unbonding_time = data[count][18];
						if(data[count][19]) child.userData.jailed = data[count][19];
						if(data[count][19] == true){
							child.material = jailedMat;
						}

						child.userData.count = count;
					}
					else {
						// var label = addText(jsonFont, 'No.' + (count + 1), vector.x, vector.y, vector.z, 0, 0, 0, child, 'label_' + (count + 1), .05, 0xFFFFFF);

						child.material = disabledMat;
					}
					count++;
				}
			});

			base.add(root);
			snub = root;
			// var geo = new THREE.EdgesGeometry(geometry); // or WireframeGeometry( geometry )
			// var mat = new THREE.LineBasicMaterial({color: 0xffffff, linewidth: 2});
			// var wireframe = new THREE.LineSegments(geo, mat);
			// root.add(wireframe);

			mixer = new THREE.AnimationMixer(root);
			gltf.animations.forEach((clip) => {
				mixer.clipAction(clip).play();
			});
		}, function(xhr) {
			// document.getElementById('loading_percentage').innerText = Math.round((xhr.loaded/xhr.total * 100)) + '% loaded';
			// console.log((xhr.loaded/xhr.total * 100) + '% loaded');
		}, function(error) {
			// console.log('An error accured');
		});
}

// Adding text
function addText(fontPath, text, x, y, z, rx, ry, rz, parent, name, size, color,id) {
    var loader = new THREE.FontLoader();

    loader.load(fontPath, function(font) {
        var textGeo = new THREE.TextGeometry(text, {
            font: font,
            size: size,
			weight: 'normal',
            height: 0.005,
            curveSegments: 6,
            bevelThickness: 0.008,
            bevelSize: 0.008,
            bevelEnabled: false,
            bevelOffset: 0,
        });

        var textMaterial = new THREE.MeshStandardMaterial({
            color: color,
			emissive: color,
			emissiveIntensity: 3 
        });

		var flip = new THREE.Matrix4().makeScale(-1,1,1);
		textGeo.applyMatrix4(flip);
        var mesh = new THREE.Mesh(textGeo, textMaterial);
        mesh.position.set(x, y, z);
        mesh.rotation.set(rx, ry, rz);
		
		//Centering text
		textGeo.computeBoundingBox();
		textGeo.center();
		mesh.geometry.dispose();
		mesh.geometry = textGeo;
        mesh.name = name;
		// var margin = (text.length / -2) * size;
		// mesh.position.x += margin;
        parent.add(mesh);
		mesh.lookAt(scene.position);
		mesh.translateZ(-0.005);
		
		mesh.rotateZ(zAxisDisplacement[id] * THREE.Math.DEG2RAD);
		mesh.translateY(-0.05);
		texts.push(mesh);
    });
}

function addPicture(sizeX,sizeY,x,y,z,rx,ry,rz,parent,name,url) {
	url = '/images/logo-placeholder-image.png'

	var textureLoader = new THREE.TextureLoader();
	textureLoader.crossOrigin = "Anonymous";
	textureLoader.load(url,function(texture){
		var planeMat = new THREE.MeshBasicMaterial({
			map: texture,
			side: THREE.DoubleSide,
			color: 0x36d6ae,
			transparent: true,
			opacity: 0.6,
			alphaTest: 0.5,

		});
		var planeGeo = new THREE.PlaneGeometry(sizeX,sizeY);
		var flip = new THREE.Matrix4().makeScale(-1,1,1);
		planeGeo.applyMatrix4(flip);
		var pic = new THREE.Mesh(planeGeo,planeMat);
		pic.name = name;
		pic.position.set(x,y,z);
		pic.rotation.set(rx,ry,rz);
		pic.layers.enable(BLOOM_SCENE);
		parent.add(pic);
		pic.lookAt(scene.position);
		pic.translateY(0.06);
		pic.translateZ(-0.06);
	});
}

// Creates spheres and applies textures to it using shaders
function addTexturedSphere(size, x, y, z, radius, texture, parent, name, bloom) {
	var geometry = new THREE.SphereGeometry(size, radius, radius);
	var material = new THREE.MeshBasicMaterial({
		map: new THREE.TextureLoader().load(texture),
		side: THREE.DoubleSide,
		transparent: true
	});
	var mesh = new THREE.Mesh(geometry, material);
	mesh.position.set(x, y, z);
	mesh.name = name;
	mesh.castShadow = true;
	mesh.receiveShadow = true;
	parent.add(mesh);
	if(bloom) {
		mesh.layers.enable(BLOOM_SCENE);
	}
	return mesh;
}

// Adds Moon
function getMoon(size, bump, opacity, x, y, z, rx, ry, rz, name, parent) {
    var geometry = new THREE.SphereGeometry(size, 32);

	//Texture from https://svs.gsfc.nasa.gov/4720
	const texture = new THREE.TextureLoader().load( 'images/Moon_texture_1024.jpg' );
	const bumpMap = new THREE.TextureLoader().load( 'images/Moon_bump_1024.jpg' );

    var material = new THREE.MeshStandardMaterial({
		map: texture,
		bumpMap: bumpMap,
		bumpScale: bump,
        side: THREE.DoubleSide,
        transparent: false,
        opacity: opacity,

    });
    var circle = new THREE.Mesh(geometry, material);
    circle.position.set(x, y, z);
    circle.rotation.set(rx, ry, rz);
    circle.name = name;
    parent.add(circle);
}

/* function createGlow(){
	const loader = new GLTFLoader();
	loader.load('/3d/triangle glow.gltf',function(obj){
		const triangleGLow = obj.scene.children[0];
		triangleGLow.position.x = 4;
		triangleGLow.scale.set(4,4,4);
		console.log(triangleGLow);
		scene.add(triangleGLow);
	});
	
}
 */
// Showing off
function render() {

	// render scene with bloom
	scene.traverse(darkenNonBloomed);
	bloomComposer.render();
	scene.traverse(restoreMaterial);

	// render the entire scene, then render bloom scene on top
	finalComposer.render(); 

}

// Rendering the bloom scene

// Adding temporary dark material to non-bloom objects
function darkenNonBloomed(obj) {
	if(obj.isMesh && bloomLayer.test(obj.layers) === false) {
		materials[obj.uuid] = obj.material;
		obj.material = darkMaterial;
	}
}

// Restoring the real material of non-bloom objects
function restoreMaterial(obj) {
	if(materials[obj.uuid]) {
		obj.material = materials[obj.uuid];
		delete materials[obj.uuid];
	}
}

function onPointerUp(event){

	mouseUp.x = (event.clientX / window.innerWidth) * 2 - 1;
	mouseUp.y = - (event.clientY / window.innerHeight) * 2 + 1;



	var target = $(event.target);

	

	//Checking clicked item's parent has "item" class
	if( target && target.parent('li').hasClass('item')){
		//Item's id
		var id = parseInt(target.parent('li').attr('id').replace('item_',''));
		var clicked_obj = snub.children[id-1];
		
		unbloom(snub);
		
		clicked_obj.layers.toggle(BLOOM_SCENE);
		outlinePass.selectedObjects = clicked_obj;
		changeTextColor(id);

		moveCamera(id - 1);
		cameraTween.start();
		//To prevent other unbloom functions from happening.
		return;
	}

	raycaster.setFromCamera(mouse, camera);
	
	//Check if the object mouse up is the same as mouse down.
	var intersectsNew = raycaster.intersectObjects(snub.children, false);
	if (intersectsNew.length > 0 ){


		if( (intersects[0].object === intersectsNew[0].object)){

		


			if(target.parents('div#popup').length) {
				// It happens when the large popup is opened and the click has been on one of its child elements
				if(event.target.id == 'close_popup') {
					unbloom(snub);
				}
			}
			else {
				if(intersects.length > 0) {
					autoRotate = false;
					unbloom(snub)

					const object = intersects[0].object;
					object.layers.toggle(BLOOM_SCENE);
					//Change texts to black
					record = object.name;
					outlinePass.selectedObjects = object;
					
					var item = showRecord(record);
					
					var track = parseInt(item.userData.place);
					
					changeTextColor(track);
					if(data[track] != undefined) {
						var operation_address = data[track][14];
						var address = data[track][5];
						var identity = data[track][7];
						var delegator_shared = data[track][6];
						var token = data[track][16];
						var commission_rate = data[track][3];
						var max_rate = data[track][2];
						var max_change_rate = data[track][1];
						var self_stake = data[track][13];
						var details = data[track][7];

		/* 				var main_content = '<ul class="info">';
						main_content += '<li><span class="label">Operation Address: </span><span>' + operation_address + '</span></li>';
						main_content += '<li><span class="label">Address: </span><span>' + address + '</span></li>';
						main_content += '<li><span class="label">Identity: </span><span>' + identity + '</span></li>';
						main_content += '<li><span class="label">Delegator Shared: </span><span>' + delegator_shared + '</span></li>';
						main_content += '<li><span class="label">Token: </span><span>' + token + '</span></li>';
						main_content += '<li><span class="label">Commission Rate: </span><span>' + commission_rate + '</span></li>';
						main_content += '<li><span class="label">Max. Rate: </span><span>' + max_rate + '</span></li>';
						main_content += '<li><span class="label">Max. Exchange Rate: </span><span>' + max_change_rate + '</span></li>';
						main_content += '<li><span class="label">Self Stake: </span><span>' + self_stake + '</span></li>';
						main_content += '<li><span class="label">Details: </span><span>' + details + '</span></li>';
						main_content += '</ul>';
						document.getElementById('main_content').innerHTML = main_content; */

						// var snubTween = new TWEEN.Tween(snub.position)
						// .to({x: -4, y: 0, z: 0}, 2000)
						// .easing(TWEEN.Easing.Cubic.InOut)
						// .start();
						//
						// var cameraTween = new TWEEN.Tween(camera.position)
						// .to({x: 0, y: 0, z: 18}, 2000)
						// .easing(TWEEN.Easing.Cubic.Out)
						// .onComplete(function() {
						// 	// Change the #tracker hidden input on intersect click
						// 	var input = document.getElementById('tracker');
						// 	input.value = item.userData.place;
						//
						// 	// Trigger event on input change
						// 	var event = new Event('input', {
						// 		bubbles: true,
						// 		cancelable: true,
						// 	});
						// 	input.dispatchEvent(event);
						// })
						// .start();

						moveCamera(track - 1);

						// Change the #tracker hidden input on intersect click
						var input = document.getElementById('tracker');
						input.value = item.userData.place;

						// 	// Trigger event on input change
						var event = new Event('input', {
							bubbles: true,
							cancelable: true,
						});
						input.dispatchEvent(event);

					}
				}
			}
			cameraTween.start();

		}
		

	}
	else{
		//Check if the mouse didn't move much (not dragged) then unbloom.
		if((Math.abs(mouse.x - mouseUp.x) < 0.015) && (Math.abs(mouse.y - mouseUp.y) < 0.015)){
			unbloom(snub);
		}
		
	}

	
}

// Animating the scene
var expanding = true;

function animate() {


	requestAnimationFrame(animate);
    galaxy.rotation.y -= Math.PI/100000;

    TWEEN.update();
    controls.update();
    // stats.update();
	
	render();
}

