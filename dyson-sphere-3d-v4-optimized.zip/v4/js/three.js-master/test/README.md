### Install test dependencies

- Execute `npm i --prefix test` from root folder
