/* global QUnit */

import { LineSegments } from '../../../../src/objects/LineSegments';

export default QUnit.module( 'Objects', () => {

	QUnit.module( 'LineSegments', () => {

		// INHERITANCE
		QUnit.todo( "Extending", ( assert ) => {

			assert.ok( false, "everything's gonna be alright" );

		} );

		// INSTANCING
		QUnit.todo( "Instancing", ( assert ) => {

			assert.ok( false, "everything's gonna be alright" );

		} );

		// PUBLIC STUFF
		QUnit.todo( "isLineSegments", ( assert ) => {

			assert.ok( false, "everything's gonna be alright" );

		} );


	} );

} );
